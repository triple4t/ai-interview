import { redirect } from 'next/navigation';

export default function Components() {
  return redirect('/components/base');
}
