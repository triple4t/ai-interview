import { InterviewAssistant } from '@/components/interview-assistant';

export default function Page() {
  return <InterviewAssistant />;
}
