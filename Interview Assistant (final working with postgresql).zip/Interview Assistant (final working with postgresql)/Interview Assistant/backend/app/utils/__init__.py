# Utils module for interview assistant
